package ridsys.example.com.news.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.squareup.picasso.Picasso;

import java.util.List;

import ridsys.example.com.news.R;
import ridsys.example.com.news.model.Datum;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {
    private List<Datum>datumList;
    private Context context;

    public CustomAdapter(Context context, List<Datum> datumList) {
        this.context=context;
        this.datumList=datumList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
       View v= LayoutInflater.from(context).inflate(R.layout.customer_adapter, viewGroup, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        ViewHolder.title.setText(datumList.get(i).getTitle());
        ViewHolder.description.setText(datumList.get(i).getDescription());
        String image=datumList.get(i).getUrlToImage();
        Log.i("image",String.valueOf(image));

       Picasso.with(context).load(image).fit().into(ViewHolder.image_view);




    }

    @Override
    public int getItemCount() {
        return datumList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public final View View;
        public static ImageView image_view;
        public static TextView title;
        public static TextView description;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            View=itemView;
            image_view=itemView.findViewById(R.id.image_view);
            title=itemView.findViewById(R.id.title1);
            description=itemView.findViewById(R.id.description);

        }
    }
}
