package ridsys.example.com.news.model;

import android.widget.TextView;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class News {
    @SerializedName("articles")
    public List<Datum> articles = new ArrayList<>();


}
