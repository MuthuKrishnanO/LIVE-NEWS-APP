package ridsys.example.com.news.network;

import retrofit2.Call;
import retrofit2.http.GET;
import ridsys.example.com.news.model.News;

public interface APIInterface {
    @GET("v2/top-headlines?country=in&category=technology&apiKey=261fe0cbb9504dd583736aa8f76095f1")
    Call<News> doResources();

}
